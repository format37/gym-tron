class LexEnv(gym.Env):

	def __init__(self):        

	def step(self, action):
		return True

	def reset(self):
		return True

	def render(self, mode='human'):
		return True

	def close(self):
		a=0